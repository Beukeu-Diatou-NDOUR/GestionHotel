package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"strings"

	_ "github.com/go-sql-driver/mysql"
)

//Structure du client

type Client struct {
	ID        int    `json:"id_client"`
	Nom       string `json:"nom_client"`
	Prenom    string `json:"prenom_client"`
	Telephone string `json:"tel_client"`
}

// Connexion à la base de données MySQL

func dbConnecte() (*sql.DB, error) {

	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return nil, err
	}
	return db, nil
}

func getClientsHandler(w http.ResponseWriter, r *http.Request) {
	// Connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(localhost:3306)/hotel")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la connexion à la base de données")
		return
	}
	defer db.Close()

	// Récupération de tous les clients depuis la table "client"
	rows, err := db.Query("SELECT id_client, nom_client, prenom_client, tel_client FROM client")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des clients depuis la base de données")
		return
	}
	defer rows.Close()

	// Boucle sur les résultats et stockage dans une slice de clients
	clients := make([]Client, 0)
	for rows.Next() {
		var client Client
		err := rows.Scan(&client.ID, &client.Nom, &client.Prenom, &client.Telephone)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			fmt.Fprintln(w, "Erreur lors de la lecture des données du client depuis la base de données")
			return
		}
		clients = append(clients, client)
	}
	if err := rows.Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des clients depuis la base de données")
		return
	}

	// Envoi des clients en format JSON dans la réponse HTTP
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(clients)
}

// Création d'un nouveau client
func createClientHandler(w http.ResponseWriter, r *http.Request) {
	// Lecture des données du client à partir du corps de la requête
	var client Client
	err := json.NewDecoder(r.Body).Decode(&client)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Connexion à la base de données
	db, err := dbConnecte()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Exécution de la requête d'insertion
	result, err := db.Exec("INSERT INTO client(nom_client, prenom_client,tel_client) VALUES (?, ?, ?)", client.Nom, client.Prenom, client.Telephone)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Récupération de l'ID généré automatiquement
	id, err := result.LastInsertId()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Création de la réponse
	client.ID = int(id)
	response, err := json.Marshal(client)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Envoi de la réponse
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(response)
}
func updateClientHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client à mettre à jour depuis les paramètres de la requête
	clientIDStr := r.URL.Query().Get("id")
	clientID, err := strconv.Atoi(clientIDStr)
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Récupère les données du client à partir du corps de la requête
	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	var updatedClient Client
	err = json.Unmarshal(reqBody, &updatedClient)
	if err != nil {
		http.Error(w, "Failed to parse request body", http.StatusBadRequest)
		return
	}

	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, "Failed to connect to database", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Prépare et exécute la requête de mise à jour du client dans la base de données
	query := "UPDATE client SET nom_client=?, prenom_client=?, tel_client=?,  WHERE id_client=?"
	_, err = db.Exec(query, updatedClient.Nom, updatedClient.Prenom, updatedClient.Telephone, clientID)
	if err != nil {
		http.Error(w, "Failed to update client in database", http.StatusInternalServerError)
		return
	}

	// Retourne une réponse HTTP 200 OK
	w.WriteHeader(http.StatusOK)
}
func deleteClientHandler(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'id du client à supprimer à partir de la requête URL
	idStr := r.URL.Query().Get("id_client")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Ouvrir la connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Préparer la requête SQL pour supprimer le client
	stmt, err := db.Prepare("DELETE FROM client WHERE id_client = ?")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer stmt.Close()

	// Exécuter la requête SQL pour supprimer le client
	res, err := stmt.Exec(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Vérifier si le client a été supprimé avec succès
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if rowsAffected == 0 {
		http.Error(w, "Client not found", http.StatusNotFound)
		return
	}

	// Renvoyer une réponse JSON pour indiquer que le client a été supprimé avec succès
	response := map[string]interface{}{
		"status":  "success",
		"message": "Client deleted successfully",
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
func getClient(clientID int) (Client, error) {
	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return Client{}, err
	}
	defer db.Close()

	// Prépare et exécute la requête de récupération du client depuis la base de données
	query := "SELECT nom_client, prenom_client, tel_client FROM client WHERE id_client=?"
	row := db.QueryRow(query, clientID)

	// Récupère les données du client depuis la ligne de résultat
	var client Client
	err = row.Scan(&client.Nom, &client.Prenom, &client.Telephone)
	if err != nil {
		if err == sql.ErrNoRows {
			return Client{}, fmt.Errorf("client with ID %d not found", clientID)
		}
		return Client{}, err
	}

	return client, nil
}

func getClientHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client depuis l'URL
	clientID, err := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/clients/"))
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Récupère le client correspondant depuis la base de données
	client, err := getClient(clientID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Encode le client en JSON et renvoie la réponse HTTP
	json.NewEncoder(w).Encode(client)
}

// Structure reservation

type Reservation struct {
	ID              int    `json:"id_reservation"`
	Nuite           int    `json:"nuite"`
	DateEntre       string `json:"date_entre"`
	DateSortie      string `json:"date_sortie"`
	DateReservation string `json:"date_reservation"`
	Dej             string `json:"petit_dej"`
	Bar             string `json:"bar"`
	Telephone       int    `json:"phone"`
	TarifChambre    int    `json:"tarif_chambre"`
	TarifDej        int    `json:"tarif_dej"`
	TarifBar        int    `json:"tarif_bar"`
	TarifPhone      int    `json:"tarif_phone"`
	ID_chambre      int    `json:"idchambre"`
	ID_service      int    `json:"idservice"`
	ID_client       int    `json:"idcli"`
	ID_chamb        int    `json:"idchamb"`
	Nom_client      string `json:"nom_cli"`
	Prenom_client   string `json:"prenom_cli"`
	Tel_cli         int    `json:"tel_cli"`
}

func dbConnect() (*sql.DB, error) {

	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return nil, err
	}
	return db, nil
}

func getReservationsHandler(w http.ResponseWriter, r *http.Request) {
	// Connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(localhost:3306)/hotel")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la connexion à la base de données")
		return
	}
	defer db.Close()

	// Récupération de tous les reservations depuis la table "reservation"
	rows, err := db.Query("SELECT id_reservation,nuite,date_entre,date_sortie,date_reservation,petit_dej,bar,phone,tarif_chambre,tarif_dej,tarif_bar,tarif_phone,idchambre,idservice,idcli,idchamb,nom_cli,prenom_cli,tel_cli FROM reservation")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des reservations depuis la base de données")
		return
	}
	defer rows.Close()

	// Boucle sur les résultats et stockage dans une slice de reservation
	reservations := make([]Reservation, 0)
	for rows.Next() {
		var reservation Reservation
		err := rows.Scan(&reservation.ID, &reservation.Nuite, &reservation.DateEntre, &reservation.DateSortie, &reservation.DateReservation, &reservation.Dej, &reservation.Bar, &reservation.Telephone, &reservation.TarifChambre, &reservation.TarifDej, &reservation.TarifBar, &reservation.TarifPhone, &reservation.ID_chambre, &reservation.ID_service, &reservation.ID_client, &reservation.ID_chamb, &reservation.Nom_client, &reservation.Prenom_client, &reservation.Tel_cli)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			fmt.Fprintln(w, "Erreur lors de la lecture des données de la reservation depuis la base de données")
			return
		}
		reservations = append(reservations, reservation)
	}
	if err := rows.Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des reservations depuis la base de données")
		return
	}

	// Envoi des clients en format JSON dans la réponse HTTP
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(reservations)
}
func createReservationHandler(w http.ResponseWriter, r *http.Request) {
	// Lecture des données du client à partir du corps de la requête
	var reservation Reservation
	err := json.NewDecoder(r.Body).Decode(&reservation)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Connexion à la base de données
	db, err := dbConnecte()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Exécution de la requête d'insertion
	result, err := db.Exec("INSERT INTO reservation(nuite,date_entre,date_sortie,date_reservation,petit_dej,bar,phone,tarif_chambre,tarif_dej,tarif_bar,tarif_phone,idchambre,idservice,idcli,idchamb,nom_cli,prenom_cli,tel_cli) VALUES (?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", reservation.Nuite, reservation.DateEntre, reservation.DateSortie, reservation.DateReservation, reservation.Dej, reservation.Bar, reservation.Telephone, reservation.TarifChambre, reservation.TarifDej, reservation.TarifBar, reservation.TarifPhone, reservation.ID_chambre, reservation.ID_service, reservation.ID_client, reservation.ID_chamb, reservation.Nom_client, reservation.Prenom_client, reservation.Tel_cli)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Récupération de l'ID généré automatiquement
	id, err := result.LastInsertId()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Création de la réponse
	reservation.ID = int(id)
	response, err := json.Marshal(reservation)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Envoi de la réponse
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(response)
}

func dbConnected() {
	panic("unimplemented")
}

func updateReservationHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client à mettre à jour depuis les paramètres de la requête
	reservationIDStr := r.URL.Query().Get("id")
	reservationID, err := strconv.Atoi(reservationIDStr)
	if err != nil {
		http.Error(w, "Invalid reservation ID", http.StatusBadRequest)
		return
	}

	// Récupère les données du client à partir du corps de la requête
	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	var updatedReservation Reservation
	err = json.Unmarshal(reqBody, &updatedReservation)
	if err != nil {
		http.Error(w, "Failed to parse request body", http.StatusBadRequest)
		return
	}

	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, "Failed to connect to database", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Prépare et exécute la requête de mise à jour du client dans la base de données
	query := "UPDATE reservation SET nuite =?,date_entre =?,date_sortie =?,date_reservation =?,petit_dej =?,bar =?,phone =?,tarif_chambre =?,tarif_dej =?,tarif_bar =?,tarif_phone =?,idchambre =?,idservice =?,idcli =?,idchamb =?,nom_cli =?,prenom_cli =?,tel_cli =? WHERE id_reservation =?"
	_, err = db.Exec(query, updatedReservation.Nuite, updatedReservation.DateEntre, updatedReservation.DateSortie, updatedReservation.DateReservation, updatedReservation.Dej, updatedReservation.Bar, updatedReservation.Telephone, updatedReservation.TarifChambre, updatedReservation.TarifDej, updatedReservation.TarifBar, updatedReservation.TarifPhone, updatedReservation.ID_chambre, updatedReservation.ID_service, updatedReservation.ID_client, updatedReservation.ID_chamb, updatedReservation.Nom_client, updatedReservation.Prenom_client, updatedReservation.Tel_cli, reservationID)
	if err != nil {
		http.Error(w, "Failed to update client in database", http.StatusInternalServerError)
		return
	}

	// Retourne une réponse HTTP 200 OK
	w.WriteHeader(http.StatusOK)
}
func deleteReservationHandler(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'id du client à supprimer à partir de la requête URL
	idStr := r.URL.Query().Get("id_reservation")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Ouvrir la connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Préparer la requête SQL pour supprimer le client
	stmt, err := db.Prepare("DELETE FROM reservation WHERE id_reservation = ?")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer stmt.Close()

	// Exécuter la requête SQL pour supprimer le client
	res, err := stmt.Exec(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Vérifier si le client a été supprimé avec succès
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if rowsAffected == 0 {
		http.Error(w, "Reservation not found", http.StatusNotFound)
		return
	}

	// Renvoyer une réponse JSON pour indiquer que le client a été supprimé avec succès
	response := map[string]interface{}{
		"status":  "success",
		"message": "Reservation deleted successfully",
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
func getReservation(reservationID int) (Reservation, error) {
	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return Reservation{}, err
	}
	defer db.Close()

	// Prépare et exécute la requête de récupération du client depuis la base de données
	query := "SELECT nuite,date_entre,date_sortie,date_reservation,petit_dej,bar,phone,tarif_chambre,tarif_dej,tarif_bar,tarif_phone,idchambre,idservice,idcli,idchamb,nom_cli,prenom_cli,tel_cli FROM reservation WHERE id_reservation=?"
	row := db.QueryRow(query, reservationID)

	// Récupère les données du client depuis la ligne de résultat
	var reservation Reservation
	err = row.Scan(&reservation.Nuite, &reservation.DateEntre, &reservation.DateSortie, &reservation.DateReservation, &reservation.Dej, &reservation.Bar, &reservation.Telephone, &reservation.TarifChambre, &reservation.TarifDej, &reservation.TarifBar, &reservation.TarifPhone, &reservation.ID_chambre, &reservation.ID_service, &reservation.ID_client, &reservation.ID_chamb, &reservation.Nom_client, &reservation.Prenom_client, &reservation.Tel_cli)
	if err != nil {
		if err == sql.ErrNoRows {
			return Reservation{}, fmt.Errorf("reservation with ID %d not found", reservationID)
		}
		return Reservation{}, err
	}

	return reservation, nil
}
func getReservationHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client depuis l'URL
	reservationID, err := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/reservations/"))
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Récupère le client correspondant depuis la base de données
	reservation, err := getReservation(reservationID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Encode le client en JSON et renvoie la réponse HTTP
	json.NewEncoder(w).Encode(reservation)
}

type Chambre struct {
	ID            int    `json:"id_chambre"`
	Numero        int    `json:"numero_chambre"`
	ID_client     int    `json:"idclient"`
	Disponibilite string `json:"etat_chambre"`
	TypeChambre   string `json:"classe_chambre"`
	ID_categorie  int    `json:"idcategorie"`
}

func dbConnexion() (*sql.DB, error) {

	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return nil, err
	}
	return db, nil
}
func getChambresHandler(w http.ResponseWriter, r *http.Request) {
	// Connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la connexion à la base de données")
		return
	}
	defer db.Close()

	// Récupération de toutes les chambres depuis la table "chambre"
	rows, err := db.Query("SELECT id_chambre, numero_chambre, etat_chambre, classe_chambre, idclient, idcategorie FROM chambre")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des chambres depuis la base de données")
		return
	}
	defer rows.Close()

	// Boucle sur les résultats et stockage dans une slice de reservation
	chambres := make([]Chambre, 0)
	for rows.Next() {
		var chambre Chambre
		err := rows.Scan(&chambre.ID, &chambre.Numero, &chambre.ID_client, &chambre.Disponibilite, &chambre.TypeChambre, &chambre.ID_categorie)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			fmt.Fprintln(w, "Erreur lors de la lecture des données  depuis la base de données")
			return
		}
		chambres = append(chambres, chambre)
	}
	if err := rows.Err(); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Erreur lors de la récupération des données depuis la base de données")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(chambres)
}
func createChambreHandler(w http.ResponseWriter, r *http.Request) {
	// Lecture des données du client à partir du corps de la requête
	var chambre Chambre
	err := json.NewDecoder(r.Body).Decode(&chambre)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Connexion à la base de données
	db, err := dbConnexion()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Exécution de la requête d'insertion
	result, err := db.Exec("INSERT INTO chambre(numero_chambre, etat_chambre, classe_chambre, idclient, idcategorie FROM chambre) VALUES (?, ?, ?,?, ?)", chambre.Numero, chambre.Disponibilite, chambre.TypeChambre, chambre.ID_client, chambre.ID_categorie)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Récupération de l'ID généré automatiquement
	id, err := result.LastInsertId()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Création de la réponse
	chambre.ID = int(id)
	response, err := json.Marshal(chambre)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Envoi de la réponse
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(response)
}

func updateChambreHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client à mettre à jour depuis les paramètres de la requête
	chambreIDStr := r.URL.Query().Get("id")
	chambreID, err := strconv.Atoi(chambreIDStr)
	if err != nil {
		http.Error(w, "Invalid Room ID", http.StatusBadRequest)
		return
	}

	// Récupère les données du client à partir du corps de la requête
	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	var updatedChambre Chambre
	err = json.Unmarshal(reqBody, &updatedChambre)
	if err != nil {
		http.Error(w, "Failed to parse request body", http.StatusBadRequest)
		return
	}

	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, "Failed to connect to database", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Prépare et exécute la requête de mise à jour du client dans la base de données
	query := "UPDATE chambre SET numero_chambre=?,etat_chambre_=?,classe_chambre=?,idclient=?, idcategorie =? WHERE id_chambre=?"
	_, err = db.Exec(query, updatedChambre.Numero, updatedChambre.Disponibilite, updatedChambre.TypeChambre, updatedChambre.ID_categorie, updatedChambre.ID_client, chambreID)
	if err != nil {
		http.Error(w, "Failed to update client in database", http.StatusInternalServerError)
		return
	}

	// Retourne une réponse HTTP 200 OK
	w.WriteHeader(http.StatusOK)
}
func deleteChambreHandler(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'id du client à supprimer à partir de la requête URL
	idStr := r.URL.Query().Get("id_client")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid client ID", http.StatusBadRequest)
		return
	}

	// Ouvrir la connexion à la base de données
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Préparer la requête SQL pour supprimer le client
	stmt, err := db.Prepare("DELETE FROM chambre WHERE id_chambre = ?")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer stmt.Close()

	// Exécuter la requête SQL pour supprimer le client
	res, err := stmt.Exec(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Vérifier si le client a été supprimé avec succès
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if rowsAffected == 0 {
		http.Error(w, "Reservation not found", http.StatusNotFound)
		return
	}

	// Renvoyer une réponse JSON pour indiquer que le client a été supprimé avec succès
	response := map[string]interface{}{
		"status":  "success",
		"message": "Room deleted successfully",
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
func getChambre(chambreID int) (Chambre, error) {
	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return Chambre{}, err
	}
	defer db.Close()

	// Prépare et exécute la requête de récupération de la chambrz depuis la base de données
	query := "SELECT numero_chambre, etat_chambre, classe_chambre, idclient, idcategorie  FROM chambre WHERE id_chambre=?"
	row := db.QueryRow(query, chambreID)

	// Récupère les données du client depuis la ligne de résultat
	var chambre Chambre
	err = row.Scan(&chambre.Numero, &chambre.ID, &chambre.Disponibilite, &chambre.TypeChambre, &chambre.ID_client, &chambre.ID_categorie)
	if err != nil {
		if err == sql.ErrNoRows {
			return Chambre{}, fmt.Errorf("room with ID %d not found", chambreID)
		}
		return Chambre{}, err
	}

	return chambre, nil
}
func getChambreHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client depuis l'URL
	chambreID, err := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/chambres/"))
	if err != nil {
		http.Error(w, "Invalid room ID", http.StatusBadRequest)
		return
	}

	// Récupère le client correspondant depuis la base de données
	chambre, err := getChambre(chambreID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Encode le client en JSON et renvoie la réponse HTTP
	json.NewEncoder(w).Encode(chambre)
}

// Statistiques
type Hotel struct {
	ID                  int    `json:"id_hotel"`
	NbreChambreReservee int    `json:"nb_chambre"`
	NbreNiveau          int    `json:"nb_niveau"`
	TauxOccupation      string `json:"tel_hotel"`
	NomHotel            string `json:"nom_hotel"`
	AdresseHotel        string `json:"adresse_hotel"`
}

func getHotel(hotelID int) (Hotel, error) {
	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		return Hotel{}, err
	}
	defer db.Close()

	// Prépare et exécute la requête de récupération de la chambrz depuis la base de données
	query := "SELECT nb_chambre,tel_hotel,nom_hotel,adresse_hotel, nb_niveau  FROM Hotel WHERE id_hotel=?"
	row := db.QueryRow(query, hotelID)

	// Récupère les données du client depuis la ligne de résultat
	var hotel Hotel
	err = row.Scan(&hotel.NbreChambreReservee, &hotel.TauxOccupation, &hotel.NomHotel, &hotel.AdresseHotel, &hotel.NbreNiveau)
	if err != nil {
		if err == sql.ErrNoRows {
			return Hotel{}, fmt.Errorf("room with ID %d not found", hotelID)
		}
		return Hotel{}, err
	}

	return hotel, nil
}
func getHotelHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client depuis l'URL
	hotelID, err := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/hotels/"))
	if err != nil {
		http.Error(w, "Invalid  ID", http.StatusBadRequest)
		return
	}

	// Récupère le client correspondant depuis la base de données
	hotel, err := getHotel(hotelID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Encode le client en JSON et renvoie la réponse HTTP
	json.NewEncoder(w).Encode(hotel)
}
func updateHotelHandler(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID du client à mettre à jour depuis les paramètres de la requête
	hotelIDStr := r.URL.Query().Get("id_hotel")
	hotelID, err := strconv.Atoi(hotelIDStr)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	// Récupère les données du client à partir du corps de la requête
	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	var updatedHotel Hotel
	err = json.Unmarshal(reqBody, &updatedHotel)
	if err != nil {
		http.Error(w, "Failed to parse request body", http.StatusBadRequest)
		return
	}

	// Ouvre une connexion à la base de données MySQL
	db, err := sql.Open("mysql", "root:@tcp(127.0.0.1:3306)/hotel")
	if err != nil {
		http.Error(w, "Failed to connect to database", http.StatusInternalServerError)
		return
	}
	defer db.Close()

	// Prépare et exécute la requête de mise à jour du client dans la base de données
	query := "UPDATE hotel  SET nb_chambre=?,tel_hotel=?,nom_hotel=?,adress_hotel=?, nb_niveau=?  WHERE id_hotel=?"
	_, err = db.Exec(query, updatedHotel.NbreChambreReservee, updatedHotel.TauxOccupation, updatedHotel.NomHotel, updatedHotel.AdresseHotel, updatedHotel.NbreNiveau, hotelID)
	if err != nil {
		http.Error(w, "Failed to update statistics in database", http.StatusInternalServerError)
		return
	}

	// Retourne une réponse HTTP 200 OK
	w.WriteHeader(http.StatusOK)
}

func main() {
	//Client
	http.HandleFunc("/clients", getClientsHandler)
	http.HandleFunc("/clients/", getClientHandler)
	http.HandleFunc("/clients/new", createClientHandler)
	http.HandleFunc("/clients/update/", updateClientHandler)
	http.HandleFunc("/clients/delete/", deleteClientHandler)
	//Reservation
	http.HandleFunc("/reservations", getReservationsHandler)
	http.HandleFunc("/reservations/", getReservationHandler)
	http.HandleFunc("/reservations/update/", updateReservationHandler)
	http.HandleFunc("/reservations/new", createReservationHandler)
	http.HandleFunc("/reservations/delete/", deleteReservationHandler)
	//Chambre
	http.HandleFunc("/chambres", getChambresHandler)
	http.HandleFunc("/chambres/", getChambreHandler)
	http.HandleFunc("/chambres/new", createChambreHandler)
	http.HandleFunc("/chambres/update/", updateChambreHandler)
	http.HandleFunc("/chambres/delete/", deleteChambreHandler)
	//Statistique
	http.HandleFunc("/hotels/", getHotelHandler)
	http.HandleFunc("/hotels/update/", updateHotelHandler)

	// Lancement du serveur sur le port 8080
	log.Fatal(http.ListenAndServe(":9090", nil))

}
